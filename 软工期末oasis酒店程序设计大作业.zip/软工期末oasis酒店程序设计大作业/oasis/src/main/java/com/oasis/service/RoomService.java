package com.oasis.service;

import com.oasis.entity.Room;
import com.oasis.repository.RoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class RoomService {

    @Autowired
    private RoomRepository roomRepository;

    // 获取所有可用的房间
    public List<Map<String, Object>> getAvailableRooms() {
        // 查找所有可用的房间
        List<Room> rooms = roomRepository.findByIsAvailableTrue();

        // 将房间数据转为适合前端显示的格式
        return rooms.stream().map(room -> {
            Map<String, Object> map = new HashMap<>();
            map.put("id", room.getId());  // 房间ID
            map.put("roomNumber", room.getRoomNumber());  // 房间号
            map.put("basePrice", room.getBasePrice());  // 基础价格
            return map;
        }).collect(Collectors.toList());
    }
}


