package com.oasis.dto;

public class PaymentRequest {
    private Long reservationId; // 预订 ID
    private double amount;      // 支付金额

    // Getters and Setters
    public Long getReservationId() {
        return reservationId;
    }

    public void setReservationId(Long reservationId) {
        this.reservationId = reservationId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }
}
