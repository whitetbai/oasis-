package com.oasis.dto;

import java.time.LocalDate;

public class DailyArrivalReport {
    private String guestName;       // 客人姓名
    private String reservationType; // 预订类型
    private Integer roomNumber;     // 房间号
    private LocalDate checkOutDate; // 离开日期

    // Constructor
    public DailyArrivalReport(String guestName, String reservationType, Integer roomNumber, LocalDate checkOutDate) {
        this.guestName = guestName;
        this.reservationType = reservationType;
        this.roomNumber = roomNumber;
        this.checkOutDate = checkOutDate;
    }

    // Getters and Setters
    public String getGuestName() {
        return guestName;
    }

    public void setGuestName(String guestName) {
        this.guestName = guestName;
    }

    public String getReservationType() {
        return reservationType;
    }

    public void setReservationType(String reservationType) {
        this.reservationType = reservationType;
    }

    public Integer getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(Integer roomNumber) {
        this.roomNumber = roomNumber;
    }

    public LocalDate getCheckOutDate() {
        return checkOutDate;
    }

    public void setCheckOutDate(LocalDate checkOutDate) {
        this.checkOutDate = checkOutDate;
    }
}
