package com.oasis.controller;

import com.oasis.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/reports")
public class ReportController {

    @Autowired
    private ReportService reportService;

    @GetMapping("/occupancy")
    public ResponseEntity<List<Map<String, Object>>> getOccupancyReport() {
        return ResponseEntity.ok(reportService.generateOccupancyReport());
    }

    @GetMapping("/revenue")
    public ResponseEntity<List<Map<String, Object>>> getRevenueReport() {
        return ResponseEntity.ok(reportService.generateRevenueReport());
    }

    @GetMapping("/discount")
    public ResponseEntity<List<Map<String, Object>>> getDiscountReport() {
        return ResponseEntity.ok(reportService.generateDiscountReport());
    }
}
