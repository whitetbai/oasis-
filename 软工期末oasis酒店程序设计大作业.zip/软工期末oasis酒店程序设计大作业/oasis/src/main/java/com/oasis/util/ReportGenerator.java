package com.oasis.util;

import org.springframework.stereotype.Component;

@Component
public class ReportGenerator {
    public String generateOccupancyReport() {
        return "Generated Occupancy Report";
    }
}
