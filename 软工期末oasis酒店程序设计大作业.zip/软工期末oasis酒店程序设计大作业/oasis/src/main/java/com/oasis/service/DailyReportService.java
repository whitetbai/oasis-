package com.oasis.service;

import com.oasis.dto.DailyArrivalReport;
import com.oasis.entity.Reservation;
import com.oasis.entity.Room;
import com.oasis.repository.ReservationRepository;
import com.oasis.repository.RoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DailyReportService {

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private RoomRepository roomRepository;

    public List<DailyArrivalReport> getDailyArrivalReport() {
        LocalDate today = LocalDate.now();

        // 查询当天的预订记录
        List<Reservation> reservations = reservationRepository.findReservationsByCheckInDate(today);

        // 转换为 DailyArrivalReport 格式
        return reservations.stream().map(reservation -> {
                    Room room = roomRepository.findById(reservation.getRoomId())
                            .orElseThrow(() -> new IllegalArgumentException("Room not found with ID: " + reservation.getRoomId()));

                    return new DailyArrivalReport(
                            "Guest #" + reservation.getCustomerId(),       // 假设客人姓名以客户ID标识
                            reservation.getReservationType(),
                            room.getRoomNumber(),
                            reservation.getCheckOutDate()
                    );
                }).sorted((a, b) -> a.getGuestName().compareToIgnoreCase(b.getGuestName())) // 按客人姓名排序
                .collect(Collectors.toList());
    }
}
