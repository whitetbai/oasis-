package com.oasis.controller;

import com.oasis.dto.ReservationRequest;
import com.oasis.entity.Reservation;
import com.oasis.service.ReservationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/reservations")
public class ReservationController {

    @Autowired
    private ReservationService reservationService;

    // 创建预订
    @PostMapping
    public ResponseEntity<Reservation> createReservation(@RequestBody ReservationRequest request) {
        if (request.getCheckInDate() == null || request.getCheckOutDate() == null) {
            throw new IllegalArgumentException("Check-in and check-out dates cannot be null.");
        }
        if (request.getCheckOutDate().isBefore(request.getCheckInDate())) {
            throw new IllegalArgumentException("Check-out date must be after check-in date.");
        }
        Reservation reservation = reservationService.createReservation(request);
        return ResponseEntity.ok(reservation);
    }

    // 根据 ID 获取预订详情
    @GetMapping("/{id}")
    public ResponseEntity<Reservation> getReservation(@PathVariable Long id) {
        Reservation reservation = reservationService.getReservationById(id);
        return ResponseEntity.ok(reservation);
    }

    // 计算价格
    @GetMapping("/calculate-price")
    public ResponseEntity<Map<String, BigDecimal>> calculatePrice(
            @RequestParam String type,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate checkIn,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate checkOut) {
        if (checkIn == null || checkOut == null) {
            throw new IllegalArgumentException("Check-in and check-out dates cannot be null.");
        }
        if (checkOut.isBefore(checkIn)) {
            throw new IllegalArgumentException("Check-out date must be after check-in date.");
        }
        long days = checkIn.until(checkOut).getDays();
        if (days <= 0) {
            throw new IllegalArgumentException("The stay duration must be at least 1 day.");
        }

        // 获取基价
        BigDecimal basePrice = reservationService.calculateBasePrice(checkIn);

        // 计算总价
        BigDecimal totalPrice = reservationService.calculateTotalPrice(type, basePrice, days);

        Map<String, BigDecimal> response = new HashMap<>();
        response.put("price", totalPrice);
        return ResponseEntity.ok(response);
    }
}
