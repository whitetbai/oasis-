package com.oasis.service;

import com.oasis.entity.Customer;
import com.oasis.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    // 注册新客户
    public Customer registerCustomer(String email, String name, String phone) {
        Customer customer = new Customer();
        customer.setEmail(email);
        customer.setName(name);
        customer.setPhone(phone);
        return customerRepository.save(customer);  // 保存到数据库
    }
}
