package com.oasis.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

public class InvoiceResponse {

    private LocalDate invoiceDate;      // 打印日期
    private String guestName;           // 客人姓名
    private Integer roomNumber;         // 房间号
    private LocalDate checkInDate;      // 入住日期
    private LocalDate checkOutDate;     // 离开日期
    private long daysOfStay;            // 入住天数
    private BigDecimal totalPrice;      // 总金额
    private LocalDate prepaymentDate;   // 提前支付日期（仅预付款预订和提前60天预订时显示）
    private BigDecimal prepaymentAmount; // 提前支付金额

    // Getter and Setter Methods
    public LocalDate getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(LocalDate invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public String getGuestName() {
        return guestName;
    }

    public void setGuestName(String guestName) {
        this.guestName = guestName;
    }

    public Integer getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(Integer roomNumber) {
        this.roomNumber = roomNumber;
    }

    public LocalDate getCheckInDate() {
        return checkInDate;
    }

    public void setCheckInDate(LocalDate checkInDate) {
        this.checkInDate = checkInDate;
    }

    public LocalDate getCheckOutDate() {
        return checkOutDate;
    }

    public void setCheckOutDate(LocalDate checkOutDate) {
        this.checkOutDate = checkOutDate;
    }

    public long getDaysOfStay() {
        return daysOfStay;
    }

    public void setDaysOfStay(long daysOfStay) {
        this.daysOfStay = daysOfStay;
    }

    public BigDecimal getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(BigDecimal totalPrice) {
        this.totalPrice = totalPrice;
    }

    public LocalDate getPrepaymentDate() {
        return prepaymentDate;
    }

    public void setPrepaymentDate(LocalDate prepaymentDate) {
        this.prepaymentDate = prepaymentDate;
    }

    public BigDecimal getPrepaymentAmount() {
        return prepaymentAmount;
    }

    public void setPrepaymentAmount(BigDecimal prepaymentAmount) {
        this.prepaymentAmount = prepaymentAmount;
    }
}
