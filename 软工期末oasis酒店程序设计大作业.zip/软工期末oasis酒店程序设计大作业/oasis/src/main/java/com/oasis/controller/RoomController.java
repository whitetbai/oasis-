package com.oasis.controller;

import com.oasis.service.RoomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/rooms")
public class RoomController {

    @Autowired
    private RoomService roomService;

    // 获取可用的房间列表
    @GetMapping("/available")
    public ResponseEntity<List<Map<String, Object>>> getAvailableRooms() {
        List<Map<String, Object>> availableRooms = roomService.getAvailableRooms();
        return ResponseEntity.ok(availableRooms);
    }
}
