package com.oasis.repository;

import com.oasis.entity.CancellationRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CancellationRecordRepository extends JpaRepository<CancellationRecord, Long> {
}
