package com.oasis.repository;

import com.oasis.entity.Room;
import com.oasis.entity.Room;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface RoomRepository extends JpaRepository<Room, Long> {
    Optional<Room> findByRoomNumber(int roomNumber);

    // 添加这个方法来查询可用房间
    List<Room> findByIsAvailableTrue();
}
