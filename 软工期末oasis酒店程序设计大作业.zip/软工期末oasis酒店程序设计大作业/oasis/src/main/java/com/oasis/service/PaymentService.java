package com.oasis.service;

import com.oasis.dto.PaymentRequest;
import com.oasis.entity.Payment;
import com.oasis.entity.Reservation;
import com.oasis.repository.PaymentRepository;
import com.oasis.repository.ReservationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private ReservationRepository reservationRepository;

    public Payment processPayment(PaymentRequest request) {
        // 根据 reservationId 查找 Reservation 对象
        Reservation reservation = reservationRepository.findById(request.getReservationId())
                .orElseThrow(() -> new RuntimeException("Reservation not found"));

        // 创建并设置 Payment 对象
        Payment payment = new Payment();
        payment.setReservation(reservation); // 设置 Reservation 关联
        payment.setAmount(BigDecimal.valueOf(request.getAmount())); // 转换为 BigDecimal
        return paymentRepository.save(payment);
    }
}
