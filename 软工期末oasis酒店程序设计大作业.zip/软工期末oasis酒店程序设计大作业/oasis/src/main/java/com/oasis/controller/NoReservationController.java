package com.oasis.controller;

import com.oasis.entity.CancellationRecord;
import com.oasis.service.NoReservationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/reservations")
public class NoReservationController {

    @Autowired
    private NoReservationService noreservationService;

    // 取消预订接口
    @DeleteMapping("/cancel/{id}")
    public ResponseEntity<String> cancelReservation(@PathVariable Long id) {
        String message = noreservationService.cancelReservation(id);
        return ResponseEntity.ok(message);
    }

    // 获取所有取消订单接口
    @GetMapping("/cancellations")
    public ResponseEntity<List<CancellationRecord>> getAllCancellations() {
        List<CancellationRecord> records = noreservationService.getAllCancellations();
        return ResponseEntity.ok(records);
    }
}
