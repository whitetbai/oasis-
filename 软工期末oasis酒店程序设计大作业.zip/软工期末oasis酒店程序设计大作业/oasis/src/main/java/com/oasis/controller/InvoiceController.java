package com.oasis.controller;

import com.oasis.dto.InvoiceResponse;
import com.oasis.service.InvoiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/invoices")
public class InvoiceController {

    @Autowired
    private InvoiceService invoiceService;

    // 根据 reservationId 生成票据
    @GetMapping("/{reservationId}")
    public InvoiceResponse generateInvoice(@PathVariable Long reservationId) {
        return invoiceService.generateInvoice(reservationId);
    }
}
