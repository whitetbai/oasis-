package com.oasis.service;

import com.oasis.dto.ReservationRequest;
import com.oasis.entity.Reservation;
import com.oasis.entity.Room;
import com.oasis.repository.ReservationRepository;
import com.oasis.repository.RoomRepository;
import com.oasis.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Month;

@Service
public class ReservationService {

    private static final BigDecimal DEFAULT_BASE_PRICE = BigDecimal.valueOf(150.0); // 默认基价

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private RoomRepository roomRepository;

    @Autowired
    private CustomerRepository customerRepository;

    // 创建预订的方法
    public Reservation createReservation(ReservationRequest request) {
        // 验证 customerId 是否有效
        customerRepository.findById(request.getCustomerId())
                .orElseThrow(() -> new IllegalArgumentException("Invalid customer ID: " + request.getCustomerId()));

        // 查找房间，根据 roomNumber 查找房间
        Room room = roomRepository.findByRoomNumber(request.getRoomNumber())
                .orElseThrow(() -> new IllegalArgumentException("Invalid room number: " + request.getRoomNumber()));

        // 更新房间的可用性
        if (!room.getIsAvailable()) {
            throw new IllegalStateException("Room " + request.getRoomNumber() + " is not available.");
        }

        // 将房间标记为不可用
        room.setIsAvailable(false);
        roomRepository.save(room);

        // 创建预订
        Reservation reservation = new Reservation();
        reservation.setCustomerId(request.getCustomerId());
        reservation.setRoomId(room.getId()); // 设置房间ID
        reservation.setCheckInDate(request.getCheckInDate());
        reservation.setCheckOutDate(request.getCheckOutDate());
        reservation.setReservationType(request.getType());
        reservation.setIsPaid(false);

        // 计算价格和折扣
        BigDecimal basePrice = calculateBasePrice(request.getCheckInDate());
        long days = request.getCheckInDate().until(request.getCheckOutDate()).getDays();
        BigDecimal discount = calculateDiscount(request.getType(), basePrice, days);
        BigDecimal totalPrice = calculateTotalPrice(request.getType(), basePrice, days);

        reservation.setPrice(totalPrice);
        reservation.setDiscount(discount);

        // 保存预订
        return reservationRepository.save(reservation);
    }

    // 根据 ID 获取预订
    public Reservation getReservationById(Long id) {
        return reservationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Reservation not found with id: " + id));
    }

    // 计算基价
    public BigDecimal calculateBasePrice(LocalDate date) {
        // 处理高峰期的价格
        if (date.getMonth() == Month.DECEMBER || date.getMonth() == Month.JANUARY) {
            return DEFAULT_BASE_PRICE.multiply(BigDecimal.valueOf(1.2));
        }
        return DEFAULT_BASE_PRICE;
    }

    // 根据类型计算总价
    public BigDecimal calculateTotalPrice(String type, BigDecimal basePrice, long days) {
        BigDecimal multiplier = switch (type.toUpperCase()) {
            case "PREPAID" -> BigDecimal.valueOf(0.75);
            case "ADVANCE_60" -> BigDecimal.valueOf(0.85);
            case "REWARD" -> BigDecimal.valueOf(0.80);
            default -> BigDecimal.ONE;
        };
        return basePrice.multiply(BigDecimal.valueOf(days)).multiply(multiplier);
    }

    // 根据类型计算折扣
    public BigDecimal calculateDiscount(String type, BigDecimal basePrice, long days) {
        BigDecimal discountRate = switch (type.toUpperCase()) {
            case "PREPAID" -> BigDecimal.valueOf(0.25);
            case "ADVANCE_60" -> BigDecimal.valueOf(0.15);
            case "REWARD" -> BigDecimal.valueOf(0.20);
            default -> BigDecimal.ZERO;
        };
        return basePrice.multiply(BigDecimal.valueOf(days)).multiply(discountRate);
    }
}
