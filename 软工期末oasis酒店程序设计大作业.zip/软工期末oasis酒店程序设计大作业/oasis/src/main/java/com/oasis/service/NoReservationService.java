package com.oasis.service;

import com.oasis.entity.CancellationRecord;
import com.oasis.entity.Reservation;
import com.oasis.entity.Room;
import com.oasis.repository.CancellationRecordRepository;
import com.oasis.repository.ReservationRepository;
import com.oasis.repository.RoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class NoReservationService {

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private RoomRepository roomRepository;

    @Autowired
    private CancellationRecordRepository cancellationRecordRepository;

    // 取消预订的方法
    public String cancelReservation(Long reservationId) {
        // 获取预订记录
        Reservation reservation = reservationRepository.findById(reservationId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid reservation ID: " + reservationId));

        // 获取房间信息
        Room room = roomRepository.findById(reservation.getRoomId())
                .orElseThrow(() -> new IllegalArgumentException("Invalid room ID: " + reservation.getRoomId()));

        // 更新房间为可用状态
        room.setIsAvailable(true);
        roomRepository.save(room);

        // 保存取消记录到取消记录表
        CancellationRecord cancellationRecord = new CancellationRecord();
        cancellationRecord.setReservationId(reservation.getId());
        cancellationRecord.setRoomNumber(room.getRoomNumber());
        cancellationRecord.setCustomerId(reservation.getCustomerId());
        cancellationRecord.setCheckInDate(reservation.getCheckInDate());
        cancellationRecord.setCheckOutDate(reservation.getCheckOutDate());
        cancellationRecord.setPrice(reservation.getPrice());
        cancellationRecord.setReservationType(reservation.getReservationType());
        cancellationRecord.setCancellationDate(LocalDateTime.now());

        cancellationRecordRepository.save(cancellationRecord);

        // 删除预订记录
        reservationRepository.delete(reservation);

        return "Reservation cancelled successfully and room " + room.getRoomNumber() + " is now available.";
    }
    public List<CancellationRecord> getAllCancellations() {
        return cancellationRecordRepository.findAll();
    }
}
