package com.oasis.service;

import com.oasis.entity.Reservation;
import com.oasis.repository.ReservationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ReportService {

    @Autowired
    private ReservationRepository reservationRepository;

    private static final int TOTAL_ROOMS = 45; // 宾馆房间总数

    // 生成预计入住报表
    public List<Map<String, Object>> generateOccupancyReport() {
        LocalDate today = LocalDate.now();
        LocalDate endDate = today.plusDays(30);

        List<Reservation> reservations = reservationRepository.findByCheckInDateBetween(today, endDate);

        Map<LocalDate, Map<String, Long>> dailyCounts = reservations.stream()
                .collect(Collectors.groupingBy(
                        Reservation::getCheckInDate,
                        Collectors.groupingBy(Reservation::getReservationType, Collectors.counting())
                ));

        List<Map<String, Object>> report = new ArrayList<>();
        long totalRoomsBooked = 0;

        for (LocalDate date : dailyCounts.keySet()) {
            Map<String, Long> counts = dailyCounts.get(date);
            long total = counts.values().stream().mapToLong(Long::longValue).sum();
            totalRoomsBooked += total;

            Map<String, Object> row = new HashMap<>();
            row.put("date", date);
            row.put("prepaid", counts.getOrDefault("PREPAID", 0L));
            row.put("advance60", counts.getOrDefault("ADVANCE_60", 0L));
            row.put("regular", counts.getOrDefault("REGULAR", 0L));
            row.put("reward", counts.getOrDefault("REWARD", 0L));
            row.put("total", total);
            report.add(row);
        }

        double averageOccupancy = reservations.isEmpty()
                ? 0
                : (double) totalRoomsBooked / (30 * TOTAL_ROOMS);

        Map<String, Object> summary = new HashMap<>();
        summary.put("averageOccupancy", averageOccupancy);
        report.add(summary);

        return report;
    }

    // 生成预计房间收入报表
    public List<Map<String, Object>> generateRevenueReport() {
        LocalDate today = LocalDate.now();
        LocalDate endDate = today.plusDays(30);

        List<Reservation> reservations = reservationRepository.findByCheckInDateBetween(today, endDate);

        Map<LocalDate, BigDecimal> dailyRevenue = reservations.stream()
                .collect(Collectors.groupingBy(
                        Reservation::getCheckInDate,
                        Collectors.reducing(BigDecimal.ZERO, Reservation::getPrice, BigDecimal::add)
                ));

        List<Map<String, Object>> report = new ArrayList<>();
        BigDecimal totalRevenue = BigDecimal.ZERO;

        for (LocalDate date : dailyRevenue.keySet()) {
            BigDecimal revenue = dailyRevenue.get(date);
            totalRevenue = totalRevenue.add(revenue);

            Map<String, Object> row = new HashMap<>();
            row.put("date", date);
            row.put("revenue", revenue);
            report.add(row);
        }

        BigDecimal averageRevenue = reservations.isEmpty()
                ? BigDecimal.ZERO
                : totalRevenue.divide(BigDecimal.valueOf(30), BigDecimal.ROUND_HALF_UP);

        Map<String, Object> summary = new HashMap<>();
        summary.put("totalRevenue", totalRevenue);
        summary.put("averageRevenue", averageRevenue);
        report.add(summary);

        return report;
    }

    // 生成奖励报表
    public List<Map<String, Object>> generateDiscountReport() {
        LocalDate today = LocalDate.now();
        LocalDate endDate = today.plusDays(30);

        // 获取未来30天的所有预订
        List<Reservation> reservations = reservationRepository.findByCheckInDateBetween(today, endDate);

        // 分日期统计奖励折扣
        Map<LocalDate, BigDecimal> dailyDiscounts = reservations.stream()
                .filter(r -> "REWARD".equalsIgnoreCase(r.getReservationType())) // 筛选奖励类型预订
                .collect(Collectors.groupingBy(
                        Reservation::getCheckInDate,
                        Collectors.reducing(BigDecimal.ZERO, reservation -> {
                            // 奖励折扣 = 原价的20%
                            BigDecimal discount = reservation.getPrice().multiply(BigDecimal.valueOf(0.2));
                            return discount;
                        }, BigDecimal::add)
                ));

        List<Map<String, Object>> report = new ArrayList<>();
        BigDecimal totalDiscount = BigDecimal.ZERO;

        // 遍历每日奖励折扣数据
        for (LocalDate date : dailyDiscounts.keySet()) {
            BigDecimal discount = dailyDiscounts.get(date);
            totalDiscount = totalDiscount.add(discount);

            Map<String, Object> row = new HashMap<>();
            row.put("date", date);
            row.put("discount", discount);
            report.add(row);
        }

        // 计算总奖励折扣和平均奖励折扣
        BigDecimal averageDiscount = reservations.isEmpty()
                ? BigDecimal.ZERO
                : totalDiscount.divide(BigDecimal.valueOf(30), BigDecimal.ROUND_HALF_UP);

        // 添加总奖励折扣和平均奖励折扣到报表
        Map<String, Object> summary = new HashMap<>();
        summary.put("totalDiscount", totalDiscount);
        summary.put("averageDiscount", averageDiscount);
        report.add(summary);

        return report;
    }

}
