package com.oasis.service;

import com.oasis.dto.InvoiceResponse;
import com.oasis.entity.Reservation;
import com.oasis.entity.Room;
import com.oasis.repository.ReservationRepository;
import com.oasis.repository.RoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

@Service
public class InvoiceService {

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private RoomRepository roomRepository;

    public InvoiceResponse generateInvoice(Long reservationId) {
        // 获取预订记录
        Reservation reservation = reservationRepository.findById(reservationId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid reservation ID: " + reservationId));

        // 获取房间信息
        Room room = roomRepository.findById(reservation.getRoomId())
                .orElseThrow(() -> new IllegalArgumentException("Invalid room ID: " + reservation.getRoomId()));

        // 计算入住天数
        long daysOfStay = ChronoUnit.DAYS.between(reservation.getCheckInDate(), reservation.getCheckOutDate());

        // 构建票据响应
        InvoiceResponse invoice = new InvoiceResponse();
        invoice.setInvoiceDate(LocalDate.now()); // 当前日期
        invoice.setGuestName("Guest #" + reservation.getCustomerId()); // 假设客人姓名以客户ID标识
        invoice.setRoomNumber(room.getRoomNumber());
        invoice.setCheckInDate(reservation.getCheckInDate());
        invoice.setCheckOutDate(reservation.getCheckOutDate());
        invoice.setDaysOfStay(daysOfStay);
        invoice.setTotalPrice(reservation.getPrice());

        // 如果是预付金预订或提前60天预订，设置预付金信息
        if ("PREPAID".equalsIgnoreCase(reservation.getReservationType()) ||
                "ADVANCE_60".equalsIgnoreCase(reservation.getReservationType())) {
            invoice.setPrepaymentDate(reservation.getCheckInDate().minusDays(90)); // 示例：预付金时间假设为提前90天
            invoice.setPrepaymentAmount(reservation.getPrice().multiply(reservation.getDiscount()));

        }

        return invoice;
    }
}
