package com.oasis.service;

import com.oasis.entity.Reservation;
import com.oasis.entity.Room;
import com.oasis.repository.ReservationRepository;
import com.oasis.repository.RoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class RoomAvailabilityService {

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private RoomRepository roomRepository;


    // 在项目启动时更新房间可用性
    @EventListener(ApplicationReadyEvent.class)
    public void updateRoomAvailability() {
        LocalDate today = LocalDate.now();

        // 查找所有当天之前已结束的预订
        List<Reservation> expiredReservations = reservationRepository.findByCheckOutDate(today);

        // 更新对应房间的可用性
        for (Reservation reservation : expiredReservations) {
            Room room = roomRepository.findById(reservation.getRoomId())
                    .orElseThrow(() -> new IllegalArgumentException("Invalid room ID: " + reservation.getRoomId()));

            if (!room.getIsAvailable()) { // 仅更新不可用的房间
                room.setIsAvailable(true);
                roomRepository.save(room); // 保存房间状态
                System.out.println("Room " + room.getRoomNumber() + " is now available.");
            }
        }
    }
}
