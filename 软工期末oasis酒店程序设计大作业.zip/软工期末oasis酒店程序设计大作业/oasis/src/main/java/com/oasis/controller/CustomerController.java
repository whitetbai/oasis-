package com.oasis.controller;


import com.oasis.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/register")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    // 处理注册请求
    @PostMapping
    public ResponseEntity<Map<String, Object>> registerCustomer(@RequestParam String email,
                                                                @RequestParam String name,
                                                                @RequestParam String phone) {
        Map<String, Object> response = new HashMap<>();

        try {
            // 调用服务层的注册逻辑
            customerService.registerCustomer(email, name, phone);
            response.put("success", true);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Registration failed.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }
}
