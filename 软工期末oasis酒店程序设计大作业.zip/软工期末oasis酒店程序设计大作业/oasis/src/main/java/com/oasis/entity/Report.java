package com.oasis.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "Report")
public class Report {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "report_date", nullable = false)
    private LocalDate reportDate;

    @Column(name = "report_type", nullable = false)
    private String reportType;

    @Lob
    private String content;

    // Getters and Setters
}
