package com.oasis.controller;

import com.oasis.dto.DailyArrivalReport;
import com.oasis.service.DailyReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/reports")
public class DailyReportController {

    @Autowired
    private DailyReportService dailyReportService;

    @GetMapping("/daily-arrivals")
    public List<DailyArrivalReport> getDailyArrivalReport() {
        return dailyReportService.getDailyArrivalReport();
    }
}
