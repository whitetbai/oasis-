package com.oasis.repository;

import com.oasis.entity.Reservation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDate;
import java.util.List;

public interface ReservationRepository extends JpaRepository<Reservation, Long> {
    // 根据入住日期范围查询预订
    List<Reservation> findByCheckInDateBetween(LocalDate startDate, LocalDate endDate);

    @Query("SELECT r FROM Reservation r WHERE r.checkInDate = :date")
    List<Reservation> findReservationsByCheckInDate(LocalDate date);

    List<Reservation> findByCheckOutDate(LocalDate date);
}
