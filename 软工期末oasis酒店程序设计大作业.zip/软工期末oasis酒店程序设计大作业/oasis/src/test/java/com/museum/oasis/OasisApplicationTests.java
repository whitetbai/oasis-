package com.museum.oasis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OasisApplicationTests {

    @Test
    void contextLoads() {
    }

}
