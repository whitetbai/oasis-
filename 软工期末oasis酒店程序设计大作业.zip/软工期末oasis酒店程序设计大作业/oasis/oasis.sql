CREATE DATABASE OpheliaOasis;

USE OpheliaOasis;
--取消订单表
CREATE TABLE cancellation_record (
                                     id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                     reservation_id BIGINT NOT NULL,
                                     room_number INT NOT NULL,
                                     customer_id BIGINT NOT NULL,
                                     check_in_date DATE NOT NULL,
                                     check_out_date DATE NOT NULL,
                                     price DECIMAL(10,2) NOT NULL,
                                     reservation_type VARCHAR(50),
                                     cancellation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- 客房表
CREATE TABLE Rooms (
                       id BIGINT AUTO_INCREMENT PRIMARY KEY,
                       room_number INT NOT NULL,
                       base_price DECIMAL(10, 2) NOT NULL,
                       is_available BOOLEAN DEFAULT TRUE
);

-- 顾客表
CREATE TABLE Customers (
                           id BIGINT AUTO_INCREMENT PRIMARY KEY,
                           name VARCHAR(255) NOT NULL,
                           email VARCHAR(255) NOT NULL,
                           phone VARCHAR(15)
);

-- 预订表
CREATE TABLE Reservations (
                              id BIGINT AUTO_INCREMENT PRIMARY KEY,
                              customer_id BIGINT,
                              room_id BIGINT,
                              reservation_type VARCHAR(50) NOT NULL,
                              check_in_date DATE NOT NULL,
                              check_out_date DATE NOT NULL,
                              price DECIMAL(10, 2) NOT NULL,
                              discount DECIMAL(10, 2) DEFAULT 0,
                              is_paid BOOLEAN DEFAULT FALSE,
                              FOREIGN KEY (customer_id) REFERENCES Customers(id),
                              FOREIGN KEY (room_id) REFERENCES Rooms(id)
);

-- 支付表
CREATE TABLE Payments (
                          id BIGINT AUTO_INCREMENT PRIMARY KEY,
                          reservation_id BIGINT,
                          payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                          amount DECIMAL(10, 2) NOT NULL,
                          FOREIGN KEY (reservation_id) REFERENCES Reservations(id)
);

-- 报表记录表
CREATE TABLE Reports (
                         id BIGINT AUTO_INCREMENT PRIMARY KEY,
                         report_date DATE NOT NULL,
                         report_type VARCHAR(50) NOT NULL,
                         content TEXT
);

INSERT INTO room (room_number, base_price, is_available) VALUES
                                                             (1, 150.0, TRUE), (2, 150.0, TRUE), (3, 150.0, TRUE),
                                                             (4, 150.0, TRUE), (5, 150.0, TRUE), (6, 150.0, TRUE),
                                                             (7, 150.0, TRUE), (8, 150.0, TRUE), (9, 150.0, TRUE),
                                                             (10, 150.0, TRUE), (11, 150.0, TRUE), (12, 150.0, TRUE),
                                                             (13, 150.0, TRUE), (14, 150.0, TRUE), (15, 150.0, TRUE),
                                                             (16, 150.0, TRUE), (17, 150.0, TRUE), (18, 150.0, TRUE),
                                                             (19, 150.0, TRUE), (20, 150.0, TRUE), (21, 150.0, TRUE),
                                                             (22, 150.0, TRUE), (23, 150.0, TRUE), (24, 150.0, TRUE),
                                                             (25, 150.0, TRUE), (26, 150.0, TRUE), (27, 150.0, TRUE),
                                                             (28, 150.0, TRUE), (29, 150.0, TRUE), (30, 150.0, TRUE),
                                                             (31, 150.0, TRUE), (32, 150.0, TRUE), (33, 150.0, TRUE),
                                                             (34, 150.0, TRUE), (35, 150.0, TRUE), (36, 150.0, TRUE),
                                                             (37, 150.0, TRUE), (38, 150.0, TRUE), (39, 150.0, TRUE),
                                                             (40, 150.0, TRUE), (41, 150.0, TRUE), (42, 150.0, TRUE),
                                                             (43, 150.0, TRUE), (44, 150.0, TRUE), (45, 150.0, TRUE);
